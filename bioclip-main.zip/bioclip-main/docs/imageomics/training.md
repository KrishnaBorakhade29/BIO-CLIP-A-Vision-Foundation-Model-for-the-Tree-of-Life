# Training

```sh
sbatch --output=/fs/ess/PAS2136/open_clip/logs/slurm/%j-baseline.log --job-name=baseline slurm/train.sh
```
